﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soul_Reaper_Registry
{
    public enum PowerType
    {
        Bankai,
        Resurreccion,
        Other
    }
}
