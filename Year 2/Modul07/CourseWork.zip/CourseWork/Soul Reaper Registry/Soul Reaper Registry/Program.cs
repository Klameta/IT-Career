﻿using System;

namespace Soul_Reaper_Registry
{
    public class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
